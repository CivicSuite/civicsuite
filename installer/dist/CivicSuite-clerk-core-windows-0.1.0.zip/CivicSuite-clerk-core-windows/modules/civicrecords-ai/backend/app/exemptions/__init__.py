# Exemption detection package
