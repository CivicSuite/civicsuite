# CivicSuite clerk-core Installer Bundle

This unsigned OSS beta bundle is self-contained for the clerk-core profile. It
includes the installer lifecycle runner, the selected platform package, and the
module source trees needed to build/start CivicRecords AI and CivicClerk with
Docker.

Start here:

```text
installer/generated/packages/clerk-core/linux/start-civicsuite-installer.sh
```

Verify the release SHA256 checksum before running install.
